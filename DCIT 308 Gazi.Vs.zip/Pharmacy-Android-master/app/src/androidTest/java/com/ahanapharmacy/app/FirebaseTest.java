package com.ahanapharmacy.app;

import android.test.InstrumentationTestCase;

/**
 * Created by arka on 4/29/16.
 */
public class FirebaseTest extends InstrumentationTestCase {
    @Override
    protected void setUp() throws Exception {
        super.setUp();

    }
}
