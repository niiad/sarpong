module owusuasare941.userlogin {

    requires  javafx.graphics;
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires mysql.connector.j;
    requires fontawesomefx;


//    opens owusuasare941.finalproject to javafx.fxml;
    opens owusuasare941.finalproject;
//    exports owusuasare941.finalproject;
}