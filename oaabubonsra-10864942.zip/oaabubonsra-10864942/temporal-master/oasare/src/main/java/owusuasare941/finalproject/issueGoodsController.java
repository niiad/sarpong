package owusuasare941.finalproject;

public class issueGoodsController {
}
