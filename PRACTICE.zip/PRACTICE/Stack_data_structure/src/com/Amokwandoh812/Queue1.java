package com.Amokwandoh812;

public interface myMethod {
    public void Queue();
}

public class Queue implements myMethod{
    public void myMethod(){
        System.out.println("I have a queue");
    }
}

