package com.Amokwandoh812;

public class Queue implements Queue1 {

}
