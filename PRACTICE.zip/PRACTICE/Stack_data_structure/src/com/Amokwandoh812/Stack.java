package com.Amokwandoh812;

public class Stack {

}
