package com.example.netmart.Controllers;

import javafx.scene.control.ChoiceBox;
import javafx.fxml.FXML;
public class issuedGoodModal {
    @FXML
    private ChoiceBox<Vendor> vendor_option;}
