package com.example.netmart.Controllers;

public class IssuedGoodsController {
}
